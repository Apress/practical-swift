import XCTest
@testable import LoggerTests

XCTMain([
     testCase(LoggerTests.allTests),
])
