import XCTest
@testable import Logger

class FakePrinter: Print {
    var printedItems: [Any] = []
    
    func customPrint(_ item: Any) {
        printedItems.append(item)
    }
}

protocol CustomPrintTestBehavior {
    func assert<T: canPrint, U: Equatable>(file: StaticString, line: UInt,
                subject: inout T,
                callsCustomPrintWithItem item: U,
                onAction action: (T) -> Void
    )
}

extension CustomPrintTestBehavior {
    func assert<T: canPrint, U: Equatable>(file: StaticString = #file, line: UInt = #line,
                subject: inout T,
                callsCustomPrintWithItem item: U,
                onAction action: (T) -> Void
    ) {
        let fakePrinter = FakePrinter()
        subject.printer = fakePrinter
        
        action(subject)
        
        XCTAssertEqual(item, fakePrinter.printedItems.last as? U, file: file, line: line)
    }
}


class LoggerTests: XCTestCase, CustomPrintTestBehavior {
    
    func testShouldDefaultTheSeverityAndPrinterProperties() {
        let subject = Logger()
        
        XCTAssertEqual(subject.severity, LogFilter.Info)
        XCTAssertTrue(subject.printer is Printer)
    }
    
    func testShouldLogTheItemBasedOnMatchingSeverity() {
        var subject = Logger()
        subject.severity = .Severe
        
        assert(subject: &subject, callsCustomPrintWithItem: "-- Hello") {
            $0.log(item: "Hello", withSeverity: .Severe)
        }
    }

    static var allTests : [(String, (LoggerTests) -> () throws -> Void)] {
        return [
            (
                "testShouldDefaultTheSeverityAndPrinterProperties",
                testShouldDefaultTheSeverityAndPrinterProperties
            ),
            (
                "testShouldLogTheItemBasedOnMatchingSeverity",
                testShouldLogTheItemBasedOnMatchingSeverity
            )
        ]
    }
}
