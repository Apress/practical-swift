
public enum LogFilter {
    case Info
    case Severe
}

/// Interface to describe printing an Any type item
public protocol Print {
    func customPrint(_ item: Any)
}

/// Trait for object composition
public protocol canPrint {
    var printer: Print { get set }
}

/// Struct that conforms to the Print protocol
public struct Printer: Print {
    public func customPrint(_ item: Any) {
        print(item)
    }
}

public class Logger: canPrint {
    
    public var severity: LogFilter
    public var printer: Print

    public init(severity: LogFilter = .Info, printer: Print = Printer()) {
		self.severity = severity
        self.printer = printer
        self.printer.customPrint("-- Starting Logger with severity: \(severity)")
	}

	public func log(item: String?, withSeverity severity: LogFilter) {
		if self.severity == severity, let i = item {
			printer.customPrint("-- \(i)")
		}
	}
}
