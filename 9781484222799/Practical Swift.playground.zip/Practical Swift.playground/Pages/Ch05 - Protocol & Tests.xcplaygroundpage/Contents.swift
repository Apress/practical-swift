//: [Previous](@previous)

import UIKit

//: Protocols & Tests
//: ---

//: Describes the ability to present view controllers
protocol CanPresentViewControllers {
    func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)?)
}

//: Value type for presenting alerts
struct AlertDisplayer {
    var canPresentControllers: CanPresentViewControllers
    
    init(canPresentControllers: CanPresentViewControllers) {
        self.canPresentControllers = canPresentControllers
    }
    
    func displayAlert(withTitle title: String?, andMessage message: String?) {
        // present UIAlertController
    }
}

//: ## Testing with protocols

class ProtocolTest {
    
    func testDisplayAlert() {
        let testObj = TestObject()
        let subject = AlertDisplayer(canPresentControllers: testObj)
        
        subject.displayAlert(withTitle: "Title", andMessage: "Message")
        
        testObj.controller != nil
        testObj.flag == true
        testObj.completion == nil
    }
    
    class TestObject: CanPresentViewControllers {
        var controller: UIViewController? = nil
        var flag: Bool? = nil
        var completion: (() -> Void)? = nil
        
        func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)?) {
            self.controller = viewControllerToPresent
            self.flag = flag
            self.completion = completion
        }
    }
}


//: ## Testing UIApplication with Protocols

struct User {}

//: View Model has a user object. Once this object is set,
//: the PushNotificationRegistrar registers for remote notifications
class ViewModel {
    var user: User? = nil {
        didSet {
            print("Registered")
            registrar.registerForRemoteNotifications()
        }
    }
    var registrar: PushNotificationRegistrar
    
    init(registrar: PushNotificationRegistrar) {
        self.registrar = registrar
    }
}

//: Protocol describes the ability to register for remote notifications
protocol PushNotificationRegistrar {
    func registerForRemoteNotifications()
}

//: Retroactive Modeling so the UIApplication conforms to our PushNotificationRegistrar
extension UIApplication: PushNotificationRegistrar {}

class TestViewModel {
    func testShouldRegisterForRemoteNotifications() {
        // Setup
        let registrar = FakeRegistrar()
        let subject = ViewModel(registrar: registrar)
        let user = User()
        
        // Action
        subject.user =  user
        
        registrar.registered == true
    }
    
    class FakeRegistrar: PushNotificationRegistrar {
        var registered = false
        func registerForRemoteNotifications() {
            registered = true
        }
    }
}


//: [Next](@next)
