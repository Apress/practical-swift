//: [Previous](@previous)

import UIKit

//: ## DRY vs. WET Testing protocols to illustrate Balanced Testing
//: ---

//: ### 1. Protocols from Ch05

protocol canPresentViewControllers {
    func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)?)
}

//: ### 2. New Protocol for mocking purposes

protocol AlertDisplayer {
    var canPresentControllers: canPresentViewControllers { get set }
    func displayAlert(withTitle title: String?, andMessage message: String?)
}

//: ### 3. New Struct to conform to protocol from step 2

struct ErrorAlertDisplayer: AlertDisplayer {
    var canPresentControllers: canPresentViewControllers
    
    init(canPresentControllers: canPresentViewControllers) {
        self.canPresentControllers = canPresentControllers
    }
    
    func displayAlert(withTitle title: String?, andMessage message: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction( UIAlertAction(title: "OK", style: .cancel, handler: nil) )
        canPresentControllers.present(alert, animated: UIView.areAnimationsEnabled, completion: nil)
    }
}

//: ### 4. New Protocol for composition

protocol canDisplayErrors: class {
    var alertDisplayer: AlertDisplayer { get set }
}

//: ### 5. View Controller used for testing

class MyViewController: UIViewController, canPresentViewControllers, canDisplayErrors {
    
    /// Lazily initialized AlertDisplayer so self can be injected
    lazy var alertDisplayer: AlertDisplayer = {
        return ErrorAlertDisplayer(canPresentControllers: self)
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        alertDisplayer.displayAlert(withTitle: "Title-1", andMessage: "Message-1")
    }
}

//: ### 6: Fake Displayer used for testing purposes

class FakeDisplayer: AlertDisplayer {
    var title: String? = nil
    var message: String? = nil
    
    var canPresentControllers: canPresentViewControllers
    
    init(presentVC: canPresentViewControllers) {
        canPresentControllers = presentVC
    }
    func displayAlert(withTitle title: String?, andMessage message: String?) {
        self.title = title
        self.message = message
    }
}

//: ## Balanced Testing
//: ---

//: ### 1. New Protocol meant for subclasses of XCTestCase

protocol AlertDisplayerTestBehavior {
    func assert<T: canDisplayErrors & canPresentViewControllers>(subject: T,
                displaysAlertWithTitle title: String?,
                andMessage message: String?,
                onAction action: (T) -> Void
    )
}

extension AlertDisplayerTestBehavior {
    func assert<T: canDisplayErrors & canPresentViewControllers>(subject: T,
                displaysAlertWithTitle title: String?,
                andMessage message: String?,
                onAction action: (T) -> Void
        ) {
        
        let fakeDisplayer = FakeDisplayer(presentVC: subject)
        subject.alertDisplayer = fakeDisplayer
        
        action(subject)
        
        print(fakeDisplayer.title == title)
        print(fakeDisplayer.message == message)
    }
}

//: ### 2. Simulate Test with behavior protocol

class Test: AlertDisplayerTestBehavior {
    
    func testShouldCallDisplayAlert() {
        let subject = MyViewController()
        
        assert(subject: subject, displaysAlertWithTitle: "Title-1", andMessage: "Message-1") {
            $0.viewDidLoad()
        }
    }
}

let testInstance = Test()
testInstance.testShouldCallDisplayAlert()

