//: [Previous](@previous)

//: ## Functional Generics
//: ---

let array1: [String?] = ["hello", nil, "goodbye"]
let dictionary: [String: Any] = ["hello":1]

//: newArray1 will be the result of filter out nil values and prefixing all strings with "Transform"
let newArray1 = array1
.filter {
    $0 != nil
}
.map { str in
    return "Transform \(str ?? "")"
}

newArray1

let newArray2 = array1.filter { str in
    return str != nil
}
.map { str in
    return "Transform \(str ?? "")"
}

newArray2

//: Flat map will transform the result to non-optional values

let newArray3 = array1.flatMap { $0 }.map { str in
    return "Transform \(str)"
}

newArray3

//: [Next](@next)
