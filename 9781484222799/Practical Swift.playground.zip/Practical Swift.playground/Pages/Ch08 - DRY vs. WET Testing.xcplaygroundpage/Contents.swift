//: [Previous](@previous)

import UIKit

//: # DRY vs WET Testing
//: ---

//: ### 1. Protocols from Ch05

protocol canPresentViewControllers {
    func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)?)
}

//: ### 2. New Protocol for mocking purposes

protocol AlertDisplayer {
    var canPresentControllers: canPresentViewControllers { get set }
    func displayAlert(withTitle title: String?, andMessage message: String?)
}

//: ### 3. New Struct to conform to protocol from step 2

struct ErrorAlertDisplayer: AlertDisplayer {
    var canPresentControllers: canPresentViewControllers
    
    init(canPresentControllers: canPresentViewControllers) {
        self.canPresentControllers = canPresentControllers
    }
    
    func displayAlert(withTitle title: String?, andMessage message: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction( UIAlertAction(title: "OK", style: .cancel, handler: nil) )
        canPresentControllers.present(alert, animated: UIView.areAnimationsEnabled, completion: nil)
    }
}

//: ### 4. New Protocol for composition

protocol canDisplayErrors: class {
    var alertDisplayer: AlertDisplayer { get set }
}

//: ### 5. View Controller used for testing

class MyViewController: UIViewController, canPresentViewControllers, canDisplayErrors {
    
    /// Lazily initialized AlertDisplayer so self can be injected
    lazy var alertDisplayer: AlertDisplayer = {
        return ErrorAlertDisplayer(canPresentControllers: self)
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        alertDisplayer.displayAlert(withTitle: "Title-1", andMessage: "Message-1")
    }
}

//: ### 6: Fake Displayer used for testing purposes

class FakeDisplayer: AlertDisplayer {
    var title: String? = nil
    var message: String? = nil
    
    var canPresentControllers: canPresentViewControllers
    
    init(presentVC: canPresentViewControllers) {
        canPresentControllers = presentVC
    }
    func displayAlert(withTitle title: String?, andMessage message: String?) {
        self.title = title
        self.message = message
    }
}

//: ### 7. Test function for MyViewController

func testShouldCallDisplayAlertWET() {
    let subject = MyViewController()
    let fake = FakeDisplayer(presentVC: subject)
    subject.alertDisplayer = fake
    
    // Action
    subject.viewDidLoad()
    
    print(fake.title == "Title-1")
    print(fake.message == "Message-1")
}

testShouldCallDisplayAlertWET()


//: ## DRY

//: ### 8. Setup all tests with the same subject and fake displayer

var subject: MyViewController!
var fakeDisplayer: FakeDisplayer!

func setUp() {
    subject = MyViewController()
    fakeDisplayer = FakeDisplayer(presentVC: subject)
    subject.alertDisplayer = fakeDisplayer
}

func testShouldCallDisplayAlertDRY() {
    subject.viewDidLoad()
    
    print(fakeDisplayer.title == "Title-1")
    print(fakeDisplayer.message == "Message-1")
}


setUp()
testShouldCallDisplayAlertDRY()

//: [Next](@next)
