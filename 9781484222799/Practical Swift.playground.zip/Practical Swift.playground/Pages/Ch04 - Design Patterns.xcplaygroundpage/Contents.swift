//: [Previous](@previous)

//: ## Design Patterns
//: ---


//: ## Dependency Injection

//: #### Without D.I.

class Service {
    func doSomething() {
        print("hello")
    }
}

class Client {
    let service: Service
    
    init() {
        service = Service()
    }
    
    func startSomething() {
        service.doSomething()
    }
}

let client = Client()
client.startSomething()

//: #### With D.I.

class DIClient {
    var service: Service
    
    init(service: Service = Service()) {
        self.service = service
    }
    
    func startSomething() {
        service.doSomething()
    }
}

//: #### Inversion of Control Container

class Container {
    typealias Closure = (Void) -> AnyObject
    var registry: [String: Closure] = [:]
    
    func register(name: String, for type: @escaping Closure) {
        registry[name] = type
    }
    
    func resolve(name: String) -> AnyObject? {
        return registry[name]?()
    }
}

let container = Container()
container.register(name: "Service") {
    Service()
}
container.register(name: "Client") {
    DIClient(service: container.resolve(name: "Service") as! Service)
}
let result = container.resolve(name: "Client") as? DIClient
result?.startSomething()

//: ## MVVM

class MyModel {
    var date: Date = Date()
}

//: #### A ViewModel that formats the date from it's model to a string

class ViewModel {
    var model: MyModel
    var dateFormatter: DateFormatter
    
    init(model: MyModel) {
        self.model = model
        self.dateFormatter = DateFormatter()
        self.dateFormatter.dateStyle = .short
    }
    
    var modelDate: String {
        return dateFormatter.string(from: model.date)
    }
}

import UIKit

//: #### UIViewController that is using the MVVM structural pattern

class MyViewController: UIViewController {
    var viewModel: ViewModel?
    var model = MyModel()
    
    @IBOutlet var dateLabel: UILabel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel = ViewModel(model: model)
    }
    
    @IBAction func setDate() {
        dateLabel?.text = viewModel?.modelDate
    }
}

//: ## Presenter

class Presenter {
    weak var view: UIView?
    
    init(view: UIView) {
        self.view = view
    }
    
    func displayAlert(on viewController: UIViewController, withTitle title: String?, message: String?, andActions actions: [UIAlertAction]) {
        let alert = createAlert(withTitle: title, message: message, andActions: actions)
        viewController.present(alert, animated: true, completion: nil)
    }
    
    func createAlert(withTitle title: String?, message: String?, andActions actions: [UIAlertAction]) -> UIAlertController {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        actions.forEach { alert.addAction($0) }
        
        return alert
    }
}

class ViewController: UIViewController {
    var presenter: Presenter?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = Presenter(view: view)
    }
    
    @IBAction func userDoesSomething() {
        let action = UIAlertAction(title: "OK", style: .destructive, handler: nil)
        presenter?.displayAlert(on: self, withTitle: "Error", message: "You did something bad", andActions: [action])
    }
}

//: ## Singleton

class MyAppState {
    static let instance: MyAppState = MyAppState()
    
    func handleSomething() {
        print("Singleton working here...")
    }
}

MyAppState.instance.handleSomething()


//: [Next](@next)
