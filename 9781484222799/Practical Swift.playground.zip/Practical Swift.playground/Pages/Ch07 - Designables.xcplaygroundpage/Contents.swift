//: [Previous](@previous)

import UIKit

//: ## Designables
//: ---

@IBDesignable class Button: UIButton {
    @IBInspectable var cornerRadius: CGFloat = 0.0
    
    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()
        
        layer.cornerRadius = cornerRadius
    }
}

@IBDesignable class Button2: UIButton {
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            layer.cornerRadius = cornerRadius
        }
    }
}

//: [Next](@next)
