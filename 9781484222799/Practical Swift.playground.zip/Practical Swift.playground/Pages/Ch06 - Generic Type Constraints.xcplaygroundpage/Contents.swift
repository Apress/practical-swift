//: [Previous](@previous)

//: ## Generic Type Constraints
//: ---

//: ## Pair struct
//: ### The pair struct contains two generic types that are constrained to the Equatable protocol

struct Pair<T: Equatable, U: Equatable>: Equatable {
    let key: T
    let value: U
}

//: Equality operator to satisfy the Equatable protocol on Pair
func ==<T, U>(lhs: Pair<T, U>, rhs: Pair<T, U>) -> Bool {
    return lhs.key == rhs.key && lhs.value == rhs.value
}

let p1 = Pair(key: "hello", value: 1)
let p2 = Pair(key: "hello", value: 1)

let p3 = Pair(key: "goodbye", value: 2)

p1 == p2 // True
p1 == p3 // False

//: [Next](@next)
