//: [Previous](@previous)

//: ## Generics
//: ---

//: ### Ability to print a string and only a string

func printString(str: String) {
    print(str)
}

let someString = "hello"

printString(str: someString)

//: ### A generic function that can print any type

func printSome<Type>(item: Type) {
    print(item)
}

let myInteger = 1
let myString = "goodbye"

printSome(item: myInteger)
printSome(item: myString)


//: ## Generic Stack

struct Stack<Type> {
    private var list: [Type] = []
    
    init(items: Type...) {
        self.list = items
    }
    
    mutating func add(items: Type...) {
        list += items
    }
    
    mutating func pop() -> Type? {
        guard list.count > 0 else { return nil }
        return list.removeLast()
    }
}

var stack1 = Stack<String>()
var stack2 = Stack<Int>()
var stack3 = Stack<Array<Int>>()

stack1.add(items: "hello", "goodbye")
stack2.add(items: 1, 2, 3)
stack3.add(items: [1, 2], [3, 4])

stack1.pop()
stack2.pop()
stack3.pop()

//: [Next](@next)
