//: [Previous](@previous)

import UIKit

//: ## Protocols in UIKit
//: ---

//: Describes an object that has a UIView property
protocol hasView {
    var view: UIView! { get set }
}

//: Describes the ability to present view controllers
protocol canPresentViewControllers {
    func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)?)
}

//: Describes the ability to block a view
protocol canBlockView {
    func block()
}

//: Extension for canBlockView where the conforming type is also HasView
extension canBlockView where Self: hasView {
    func block() {
        // block the view
    }
}

//: ### Alert Displayer using struct and protocol

struct AlertDisplayer {
    var canPresentControllers: canPresentViewControllers
    
    init(canPresentControllers: canPresentViewControllers) {
        self.canPresentControllers = canPresentControllers
    }
    
    func displayAlert(withTitle title: String?, andMessage message: String?) {
        // present UIAlertController
    }
}

extension UIViewController: canPresentViewControllers {}

let viewCtrl = UIViewController()
let alertDisplayer = AlertDisplayer(canPresentControllers: viewCtrl)
alertDisplayer.canPresentControllers

let secondAD = alertDisplayer
secondAD.canPresentControllers

//: [Next](@next)
