//: [Previous](@previous)

import UIKit
import PlaygroundSupport

//: ## Auto Layout & Constraints
//: ---

//: UIView meant to act as the playgrounds view in the timeline
let view = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 800))
view.backgroundColor = .white
PlaygroundPage.current.liveView = view

//: UIButton at the bottom left of the view
let orangeButton = UIButton(frame: .zero)
orangeButton.backgroundColor = .orange
orangeButton.setTitle("Button 1", for: .normal)

//: UIButton at the bottom right of the view
let greenButton = UIButton(frame: .zero)
greenButton.backgroundColor = .green
greenButton.setTitle("Button 2", for: .normal)

//: Inner UIView
let purpleView = UIView(frame: .zero)
purpleView.backgroundColor = .purple

view.addSubview(orangeButton)
view.addSubview(greenButton)
view.addSubview(purpleView)

//: ## This is a crucial step for working with constraints in code
//: ---

orangeButton.translatesAutoresizingMaskIntoConstraints = false
greenButton.translatesAutoresizingMaskIntoConstraints = false
purpleView.translatesAutoresizingMaskIntoConstraints = false

//: ---

var constraints: [NSLayoutConstraint] = []

constraints += [
    orangeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
    orangeButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10),
    orangeButton.trailingAnchor.constraint(equalTo: greenButton.leadingAnchor, constant: -10),
    orangeButton.topAnchor.constraint(equalTo: purpleView.bottomAnchor, constant: 10),
    orangeButton.firstBaselineAnchor.constraint(equalTo: greenButton.firstBaselineAnchor)
]

constraints += [
    greenButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
    greenButton.widthAnchor.constraint(equalTo: orangeButton.widthAnchor)
]

constraints += [
    purpleView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
    purpleView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
    purpleView.topAnchor.constraint(equalTo: view.topAnchor, constant: 10)
]

//: Activate all constraints

NSLayoutConstraint.activate(constraints)

//: [Next](@next)
