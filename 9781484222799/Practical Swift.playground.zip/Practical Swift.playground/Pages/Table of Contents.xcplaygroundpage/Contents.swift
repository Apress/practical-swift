//: # Practical Swift
//: ## Table Of Contents

/*:
 ### Chapter 4: Architecture
 ---
 
 * Ch04 - Design Patterns
 
 */

/*:
 ### Chapter 5: Protocol Oriented Programming
 ---
 
 * Ch05 - What are Protocols?
 * Ch05 - Protocol Oriented Thinking Pt1
 * Ch05 - Protocol Oriented Thinking Pt2
 * Ch05 - Protocols in SpriteKit
 * Ch05 - Value & Reference Types
 * Ch05 - Protocols in UIKit
 * Ch05 - Protocols & Tests
 
 */

/*:
 ### Chapter 6: Generics
 ---
 
 * Ch06 - Generics
 * Ch06 - Functional Generics
 * Ch06 - Generic Type Constraints
 * Ch06 - Protocol Associated Types
 
 */

/*:
 ### Chapter 7: UI & Storyboards
 ---
 
 * Ch07 - Auto Layout & Constraints
 * Ch07 - Blocking a View
 * Ch07 - Designables
 
 */

/*:
 ### Chapter 8: Testing
 ---
 
 * Ch08 - Mocks
 * Ch08 - DRY vs. WET Testing
 * Ch08 - Balanced Testing
 
 */


//: [Next](@next)
