//: [Previous](@previous)

//: ## Value & Reference Types
//: ---

//: ### Basics of Value Types

//: Thing struct has an id that can be mutated
struct Thing {
    var id: Int
    
    mutating func change(id: Int) {
        self.id = id
    }
}

let thing1 = Thing(id: 1)
var thing2 = thing1
thing2.change(id: 2)

thing1.id
thing2.id

//: ### Basics of Reference types

//: Object class has an id that can be mutated
class Object {
    var id: Int
    
    init(id: Int) {
        self.id = id
    }
}

let object1 = Object(id: 1)
let object2 = object1
object2.id = 2

object1.id
object2.id

//: [Next](@next)
