//: [Previous](@previous)

//: ## Mocks
//: ---

//: Protocol to allow subclass to be "mocked" via the Mocked object
protocol Mockable {
    var mocked: Mocked { get }
    
    func record(method call: String, with parameters: Any...)
    func value<T>(for call: String) -> T?
    func set(value: Any?, for call: String)
    func invocations(for call: String) -> Int
    func parameters(for call: String) -> [MockParameter]
}

extension Mockable {
    func record(method call: String, with parameters: Any...) {
        mocked.record(method: call, with: parameters)
    }
    
    func value<T>(for call: String) -> T? {
        return mocked.value(for: call)
    }
    
    func set(value: Any?, for call: String) {
        mocked.set(value: value, for: call)
    }
    
    func invocations(for call: String) -> Int {
        return mocked.invocations(for: call)
    }
    
    func parameters(for call: String) -> [MockParameter] {
        return mocked.parameters(for: call)
    }
}

//: MockParamter uses a generic method to handle parameter conversion
struct MockParameter {
    var param: Any
    
    init(value: Any) {
        param = value
    }
    
    func value<T>() -> T? {
        return param as? T
    }
}

//: Mocked class drives the data behind mocking objects.  Records method calls with parameters and return values
class Mocked {
    typealias Invocation = (signature: String, parameters: [Any])
    typealias ReturnValue = (signature: String, value: Any)
    
    var calls: [Invocation]
    var returnValues: [ReturnValue]
    
    init() {
        calls = []
        returnValues = []
    }
    
    /// Append a method call with the parameters
    func record(method call: String, with parameters: Any...) {
        calls.append( Invocation(signature: call, parameters: parameters) )
    }
    
    /// Get the return value for a method call
    func value<T>(for call: String) -> T? {
        return returnValues.first {
            $0.signature == call
        }?.value as? T
    }
    
    /// Set the return value for a method call
    func set(value: Any, for call: String) {
        returnValues.append( ReturnValue(signature: call, value: value) )
    }
    
    /// Get the number of invocations for a method call
    func invocations(for call: String) -> Int {
        return calls.filter {
            $0.signature == call
        }.count
    }
    
    /// Get the parameters for a method call
    func parameters(for call: String) -> [MockParameter] {
        let invocation = calls.first {
            $0.signature == call
        }
        return invocation?.parameters.flatMap {
            MockParameter(value: $0)
        } ?? []
    }
}

//: [Next](@next)
