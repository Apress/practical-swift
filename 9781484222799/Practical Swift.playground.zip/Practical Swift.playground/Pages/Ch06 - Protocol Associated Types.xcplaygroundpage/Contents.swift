//: [Previous](@previous)

//: ## Protocol Associated Types
//: ---

class ViewModel {
    func doSomething() {
        print("A")
    }
}

protocol ViewModelContainer {
    
    associatedtype VM: ViewModel
    var viewModel: VM { get set }
    
    mutating func set(viewModel vm: VM)
}

extension ViewModelContainer {
    mutating func set(viewModel vm: VM) {
        viewModel = vm
    }
}

class SomethingViewModel: ViewModel {}

class Something: ViewModelContainer {
    var viewModel: SomethingViewModel
    
    init() {
        viewModel = SomethingViewModel()
    }
}

let s = Something()
s.viewModel

func viewModelDoSomething<T: ViewModelContainer>(subject: T) {
    subject.viewModel.doSomething()
}

viewModelDoSomething(subject: s)

//: [Next](@next)
