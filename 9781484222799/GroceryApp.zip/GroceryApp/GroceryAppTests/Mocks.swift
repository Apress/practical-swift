//
//  Mocks.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/1/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit
import CoreData
@testable import GroceryApp

class MockPersistantContainer: PersistentContainer {
    var persistentContainer: NSPersistentContainer
    var managedObjectContext: NSManagedObjectContext = MockManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
    
    init() {
        persistentContainer = NSPersistentContainer(name: "fake", managedObjectModel: NSManagedObjectModel(byMerging: [])!)
    }
}

class MockManagedObjectContext: NSManagedObjectContext, Mockable {
    var mocked: Mocked = Mocked()
    
    override func save() throws {
        record(method: "save")
    }
    
    override func performAndWait(_ block: @escaping () -> Void) {
        record(method: "performAndWait", with: block)
        block()
    }
}

/// Used for testing purposes only
class FakeDisplayer: AlertDisplayer, Mockable {
    var mocked: Mocked = Mocked()
    
    static var displayAlert = "displayAlertWithTitleMessageWithHandler"
    
    var viewControllerPresenter: canPresentViewControllers
    
    init(viewControllerPresenter: canPresentViewControllers) {
        self.viewControllerPresenter = viewControllerPresenter
    }
    
    func displayAlert(withTitle title: String?, message: String?, withHandler handler: @escaping (UIAlertAction) -> Void) {
        record(method: FakeDisplayer.displayAlert, with: title, message)
    }
}
