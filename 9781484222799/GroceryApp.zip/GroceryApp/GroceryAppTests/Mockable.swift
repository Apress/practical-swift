//
//  Mockable.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/1/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import Foundation

struct MockParameter {
    var param: Any
    
    init(value: Any) {
        param = value
    }
    
    func value<T>() -> T? {
        return param as? T
    }
}

class Mocked {
    typealias Invocation = (signature: String, parameters: [Any])
    typealias ReturnValue = (signature: String, value: Any)
    
    var calls: [Invocation]
    var returnValues: [ReturnValue]
    
    init() {
        calls = []
        returnValues = []
    }
    
    func record(method call: String, with parameters: [Any]) {
        calls.append( Invocation(signature: call, parameters: parameters) )
    }
    
    func set(value: Any, for call: String) {
        returnValues.append( ReturnValue(signature: call, value: value) )
    }
    
    func value<T>(for call: String) -> T? {
        return returnValues.first {
            $0.signature == call
            }?.value as? T
    }
    
    func invocations(for call: String) -> Int {
        return calls.filter {
            $0.signature == call
            }.count
    }
    
    func parameters(for call: String) -> [MockParameter] {
        let invocation = calls.first {
            $0.signature == call
        }
        return invocation?.parameters.flatMap {
            MockParameter(value: $0)
            } ?? []
    }
}

protocol Mockable {
    var mocked: Mocked { get set }
    
    func record(method call: String, with parameters: Any...)
    func set(value: Any?, for call: String)
    func value<T>(for call: String) -> T?
    func invocations(for call: String) -> Int
    func parameters(for call: String) -> [MockParameter]
}

extension Mockable {
    func record(method call: String, with parameters: Any...) {
        mocked.record(method: call, with: parameters)
    }
    
    func set(value: Any?, for call: String) {
        mocked.set(value: value, for: call)
    }
    
    func value<T>(for call: String) -> T? {
        return mocked.value(for: call)
    }
    
    func invocations(for call: String) -> Int {
        return mocked.invocations(for: call)
    }
    
    func parameters(for call: String) -> [MockParameter] {
        return mocked.parameters(for: call)
    }
}

