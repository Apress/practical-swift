//
//  TestBehaviors.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/3/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit
import XCTest
@testable import GroceryApp

protocol AlertDisplayerTestBehavior {
    func assert<T: canDisplayAlerts & canPresentViewControllers>(
        file: StaticString, line: UInt,
        subject: inout T,
        displaysAlertWithTitle title: String?,
        andMessage message: String?,
        onAction action: (T) -> Void
    )
}

extension AlertDisplayerTestBehavior {
    func assert<T: canDisplayAlerts & canPresentViewControllers>(
        file: StaticString = #file, line: UInt = #line,
        subject: inout T,
        displaysAlertWithTitle title: String?,
        andMessage message: String?,
        onAction action: (T) -> Void
    ) {
        
        let fakeDisplayer = FakeDisplayer(viewControllerPresenter: subject)
        subject.alertDisplayer = fakeDisplayer
        
        action(subject)
        
        let parameters = fakeDisplayer.parameters(for: FakeDisplayer.displayAlert)
        XCTAssertEqual(title, parameters.first?.value(), file: file, line: line)
        
        let messageParameter: String? = parameters.last?.value()
        XCTAssertEqual(true, messageParameter?.contains(message ?? ""), file: file, line: line)
    }
}
