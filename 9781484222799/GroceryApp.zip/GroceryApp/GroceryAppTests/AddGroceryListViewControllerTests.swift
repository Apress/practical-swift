//
//  AddGroceryListViewControllerTests.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/3/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import XCTest
@testable import GroceryApp

class AddGroceryListViewControllerTests: XCTestCase, AlertDisplayerTestBehavior {
    
    func testShouldDisplayError() {
        var subject = AddGroceryListViewController()
        subject.viewModel = FakeGroceryListsViewModel()
        
        assert(subject: &subject, displaysAlertWithTitle: "Error", andMessage: "An error occurred.") {
            $0.addList()
        }
    }
    
    private class FakeGroceryListsViewModel: GroceryListsViewModel {
        private override func createGroceryList(with name: String?) throws {
            throw GroceryDataError.Saving("An error occurred.")
        }
    }
}
