//
//  ViewModelTests.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/1/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import XCTest
import CoreData
@testable import GroceryApp

class ViewModelTests: XCTestCase {
    
    var mockPersistentContainer: MockPersistantContainer!
    
    override func setUp() {
        super.setUp()
        
        mockPersistentContainer = MockPersistantContainer()
    }
    
    func testFetchReturnsArrayOfManagedObjects() {
        let spy = MockViewModel(persistentContainer: mockPersistentContainer)
        let expected = [NSManagedObject()]
        spy.set(value: expected, for: "executeRequest")
        
        // Action
        let result: [NSManagedObject]? = spy.fetch()
        
        // Asserts
        let objectContext = mockPersistentContainer.managedObjectContext as? MockManagedObjectContext
        XCTAssertEqual(1, objectContext?.invocations(for: "performAndWait"))
        XCTAssertEqual(1, spy.invocations(for: "executeRequest"))
        XCTAssertEqual(expected, result ?? [])
    }
    
    class MockViewModel: ViewModel, Mockable {
        var mocked: Mocked = Mocked()
        
        override func executeRequest<Type : NSManagedObject>() throws -> [Type]? {
            record(method: "executeRequest")
            return value(for: "executeRequest")
        }
    }
}
