//
//  GroceryListsViewController.swift
//  GroceryApp
//
//  Created by Downey, Eric on 9/29/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit

class GroceryListsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, ViewModelContainer {
    
    // MARK: - Properties
    
    var viewModel: GroceryListsViewModel = GroceryListsViewModel()
    
    @IBOutlet var groceryListTableView: UITableView?
    
    // MARK: - Segue

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        if var groceryListContainer = segue.destination as? SelectedGroceryListContainer,
            let indexPath = groceryListTableView?.indexPathForSelectedRow {
            
                viewModel.transferGroceryList(at: indexPath, to: &groceryListContainer)
        }
        
        if var reloadContainer = segue.destination as? ReloadContainer {
            reloadContainer.reloadData = groceryListTableView?.reloadData
        }
    }
    
    @IBAction func unwindToGroceryLists(segue: UIStoryboardSegue) {
        groceryListTableView?.reloadData()
    }
    
    // MARK: - Table View
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.groceryLists.count
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let list = viewModel.groceryList(at: indexPath)
        
        cell.textLabel?.text = list.name
        cell.detailTextLabel?.text = "\(list.itemCount) Items"
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return tableView.dequeueReusableCell(withIdentifier: GAConstants.TableCell.rightDetail, for: indexPath)
    }
}
