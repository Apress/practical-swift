//
//  AddGroceryListViewController.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/1/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit

class AddGroceryListViewController: UIViewController, ViewModelContainer, canDisplayAlerts, canBlockView {
    
    // MARK: - Properties
    
    lazy var alertDisplayer: AlertDisplayer = {
        ErrorAlertDisplayer(viewControllerPresenter: self)
    }()
    
    var viewModel: GroceryListsViewModel = GroceryListsViewModel()
    
    @IBOutlet var groceryListName: UITextField?
    
    // MARK: - Actions
    
    @IBAction func dismiss() {
        dismiss(animated: UIView.areAnimationsEnabled, completion: nil)
    }
    
    @IBAction func addList() {
        block()
        do {
            try viewModel.createGroceryList(with: groceryListName?.text)
            
            performSegue(withIdentifier: GAConstants.Segues.unwindToGroceryLists, sender: nil)
        }
        catch {
            unblock()
            alertDisplayer.displayAlert(withTitle: "Error", message: "\(error)", withHandler: {_ in })
        }
    }
}
