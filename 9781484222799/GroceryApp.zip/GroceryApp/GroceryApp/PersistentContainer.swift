//
//  PersistenContainer.swift
//  GroceryApp
//
//  Created by Downey, Eric on 9/30/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import CoreData

protocol PersistentContainer {
    var persistentContainer: NSPersistentContainer { get set }
    var managedObjectContext: NSManagedObjectContext { get }
}

extension PersistentContainer {
    var managedObjectContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
}
