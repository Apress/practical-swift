//
//  ViewModelContainer.swift
//  GroceryApp
//
//  Created by Downey, Eric on 9/29/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import Foundation

protocol ViewModelContainer {
    associatedtype VM: ViewModel
    
    var viewModel: VM { get set }
}
