//
//  AddGroceryItemViewController.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/4/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit

class AddGroceryItemViewController: UIViewController, ViewModelContainer, canDisplayAlerts, canBlockView, SelectedGroceryListContainer {
    
    // MARK: - Properties
    
    var selectedGroceryList: GroceryList? {
        get {
            return viewModel.groceryList
        }
        set {
            viewModel.groceryList = newValue
        }
    }
    
    var viewModel: GroceryItemsViewModel = GroceryItemsViewModel()
    
    lazy var alertDisplayer: AlertDisplayer = {
        ErrorAlertDisplayer(viewControllerPresenter: self)
    }()
    
    @IBOutlet var groceryItemName: UITextField?
    @IBOutlet var groceryItemQuantity: UITextField?
    
    // MARK: - Actions
    
    @IBAction func dismiss() {
        dismiss(animated: UIView.areAnimationsEnabled, completion: nil)
    }
    
    @IBAction func addItem() {
        block()
        do {
            let quantity = Int( groceryItemQuantity?.text ?? "0" )
            try viewModel.createGroceryItem(with: groceryItemName?.text, and: quantity)
            
            performSegue(withIdentifier: GAConstants.Segues.unwindToGroceryItems, sender: nil)
        }
        catch {
            unblock()
            alertDisplayer.displayAlert(withTitle: "Error", message: "\(error)", withHandler: { _ in })
        }
    }
}
