//
//  ViewBlockingProtocols.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/3/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit

protocol hasView {
    var view: UIView! { get set }
}

//: Describes the ability to block a view
protocol canBlockView {
    func block()
    func unblock()
}

//: Extension for canBlockView to implement the code to actual block the view
extension canBlockView where Self: hasView {
    func block() {
        let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
        let blockingView = UIView(frame: .zero)
        blockingView.tag = 252
        
        blockingView.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 0.75)
        
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        blockingView.translatesAutoresizingMaskIntoConstraints = false
        
        blockingView.addSubview(activityIndicator)
        view.addSubview(blockingView)
        
        NSLayoutConstraint.activate(
            constraints(for: activityIndicator, on: blockingView) +
                constraints(for: blockingView)
        )
        
        activityIndicator.startAnimating()
    }
    
    func unblock() {
        view.viewWithTag(252)?.removeFromSuperview()
    }
    
    private func constraints(for indicator: UIActivityIndicatorView, on blockingView: UIView) -> [NSLayoutConstraint] {
        return [
            indicator.centerXAnchor.constraint(equalTo: blockingView.centerXAnchor),
            indicator.centerYAnchor.constraint(equalTo: blockingView.centerYAnchor)
        ]
    }
    
    private func constraints(for blockingView: UIView) -> [NSLayoutConstraint] {
        return [
            blockingView.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            blockingView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            blockingView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0),
            blockingView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0)
        ]
    }
}


/// Retroactive Modeling so all view controllers conform to
/// - hasView
extension UIViewController: hasView {}

