//
//  GroceryItem+CoreDataProperties.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/1/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import Foundation
import CoreData

extension GroceryItem {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<GroceryItem> {
        return NSFetchRequest<GroceryItem>(entityName: "GroceryItem");
    }

    @NSManaged public var name: String?
    @NSManaged public var quantity: Int16
    @NSManaged public var list: GroceryList?

}
