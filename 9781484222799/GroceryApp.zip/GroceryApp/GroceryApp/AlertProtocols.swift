//
//  AlertProtocols.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/3/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit

/// Trait Style Protocol for presentation of view controllers
protocol canPresentViewControllers {
    func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)?)
}

/// Interface Style Protocol that represents the concept of an AlertDisplayer
protocol AlertDisplayer {
    var viewControllerPresenter: canPresentViewControllers { get set }
    
    func displayAlert(withTitle title: String?, message: String?, withHandler handler: @escaping (UIAlertAction) -> Void)
}

/// Trait Style Protocol for displaying alerts through the use of an AlertDisplayer
protocol canDisplayAlerts {
    var alertDisplayer: AlertDisplayer { get set }
    func displayAlert(withTitle title: String?, message: String?, withHandler handler: @escaping (UIAlertAction) -> Void)
}

/// Extension that allows any canDisplayAlerts to communicate with the AlertDisplayer via a method mixed into self
extension canDisplayAlerts {
    func displayAlert(withTitle title: String?, message: String?, withHandler handler: @escaping (UIAlertAction) -> Void) {
        alertDisplayer.displayAlert(withTitle: title, message: message, withHandler: handler)
    }
}


/// Retroactive Modeling: Any UIViewController has the traits
/// - canPresentViewControllers
extension UIViewController: canPresentViewControllers {}
