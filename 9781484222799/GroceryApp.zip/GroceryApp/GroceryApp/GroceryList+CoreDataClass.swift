//
//  GroceryList+CoreDataClass.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/1/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import Foundation
import CoreData

public class GroceryList: NSManagedObject {

    convenience init?(managedObjectContext: NSManagedObjectContext?) {
        guard   let mObjCtx = managedObjectContext,
                let entity = NSEntityDescription.entity(forEntityName: GAConstants.Entities.groceryList, in: mObjCtx)
        else {
            return nil
        }
        self.init(entity: entity, insertInto: mObjCtx)
    }
}
