//
//  GAConstants.swift
//  GroceryApp
//
//  Created by Downey, Eric on 9/30/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import Foundation

/// Grocery App Constants
struct GAConstants {
    
    /// Constants for our table views
    struct TableCell {
        /// Cell Identifier for our the grocery list and grocery item table views
        static let rightDetail = "Cell"
    }
    
    /// Constants for Core Data entities
    struct Entities {
        /// Entity Identifier for the GroceryList entity in Core Data
        static let groceryList = "GroceryList"
        static let groceryItem = "GroceryItem"
    }
    
    /// Constants for App Segues
    struct Segues {
        /// Unwind Segue Identifier
        static let unwindToGroceryLists = "unwindToGroceryLists"
        static let unwindToGroceryItems = "unwindToGroceryItems"
    }
}
