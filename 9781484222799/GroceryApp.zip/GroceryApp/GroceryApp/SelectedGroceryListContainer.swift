//
//  SelectedGroceryListContainer.swift
//  GroceryApp
//
//  Created by Downey, Eric on 9/30/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import Foundation

protocol SelectedGroceryListContainer {
    var selectedGroceryList: GroceryList? { get set }
}
