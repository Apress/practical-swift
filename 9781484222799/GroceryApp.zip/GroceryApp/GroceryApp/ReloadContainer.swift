//
//  ReloadContainer.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/4/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import Foundation

protocol ReloadContainer {
    var reloadData: ((Void) -> Void)? { get set }
}
