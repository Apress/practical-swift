//
//  ErrorAlertDisplayer.swift
//  GroceryApp
//
//  Created by Downey, Eric on 10/3/16.
//  Copyright © 2016 Eric Downey. All rights reserved.
//

import UIKit

/// Struct used to present UIAlertControllers using the canPresentViewControllers protocol
struct ErrorAlertDisplayer: AlertDisplayer {
    var viewControllerPresenter: canPresentViewControllers
    
    init(viewControllerPresenter: canPresentViewControllers) {
        self.viewControllerPresenter = viewControllerPresenter
    }
    
    func displayAlert(withTitle title: String?, message: String?, withHandler handler: @escaping (UIAlertAction) -> Void) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction( UIAlertAction(title: "OK", style: .cancel, handler: handler) )
        
        viewControllerPresenter.present(alert, animated: UIView.areAnimationsEnabled, completion: nil)
    }
}
